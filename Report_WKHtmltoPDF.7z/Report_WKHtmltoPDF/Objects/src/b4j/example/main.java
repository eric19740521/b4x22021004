package b4j.example;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.io.*;

import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 400);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _button1 = null;
public static String _pdfname = "";
public static String _repfolder = "";
public static anywheresoftware.b4a.objects.B4XViewWrapper _button3 = null;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 17;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 18;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 19;BA.debugLine="MainForm.RootPane.LoadLayout(\"main\") 'Load the la";
_mainform.getRootPane().LoadLayout(ba,"main");
 //BA.debugLineNum = 22;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4j.object.JavaObject  _asjo(anywheresoftware.b4j.object.JavaObject _o) throws Exception{
 //BA.debugLineNum = 107;BA.debugLine="Sub asJO(o As JavaObject)As JavaObject";
 //BA.debugLineNum = 108;BA.debugLine="Return o";
if (true) return _o;
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
return null;
}
public static String  _button1_click() throws Exception{
 //BA.debugLineNum = 103;BA.debugLine="Private Sub Button1_Click";
 //BA.debugLineNum = 104;BA.debugLine="PrintPdf";
_printpdf();
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return "";
}
public static void  _button3_click() throws Exception{
ResumableSub_Button3_Click rsub = new ResumableSub_Button3_Click(null);
rsub.resume(ba, null);
}
public static class ResumableSub_Button3_Click extends BA.ResumableSub {
public ResumableSub_Button3_Click(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
anywheresoftware.b4j.objects.Shell _pdfsh = null;
int _n = 0;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
String _strhtml = "";
String[] _p = null;
boolean _success = false;
int _exitcode = 0;
String _stdout = "";
String _stderr = "";
int step7;
int limit7;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 196;BA.debugLine="Dim PdfSh As Shell";
_pdfsh = new anywheresoftware.b4j.objects.Shell();
 //BA.debugLineNum = 199;BA.debugLine="File.Delete(repfolder,\"temp1.html\")";
anywheresoftware.b4a.keywords.Common.File.Delete(parent._repfolder,"temp1.html");
 //BA.debugLineNum = 200;BA.debugLine="File.Delete(repfolder,\"temp2.html\")";
anywheresoftware.b4a.keywords.Common.File.Delete(parent._repfolder,"temp2.html");
 //BA.debugLineNum = 202;BA.debugLine="Dim n As Int";
_n = 0;
 //BA.debugLineNum = 203;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 205;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 206;BA.debugLine="For n=1 To 1000";
if (true) break;

case 1:
//for
this.state = 4;
step7 = 1;
limit7 = (int) (1000);
_n = (int) (1) ;
this.state = 11;
if (true) break;

case 11:
//C
this.state = 4;
if ((step7 > 0 && _n <= limit7) || (step7 < 0 && _n >= limit7)) this.state = 3;
if (true) break;

case 12:
//C
this.state = 11;
_n = ((int)(0 + _n + step7)) ;
if (true) break;

case 3:
//C
this.state = 12;
 //BA.debugLineNum = 207;BA.debugLine="sb.Append($\"<tr Height=\"40\">\"$&CRLF)";
_sb.Append(("<tr Height=\"40\">")+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 208;BA.debugLine="sb.Append($\"<td style=\"text-align: left;\">A${Num";
_sb.Append(("<td style=\"text-align: left;\">A"+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(anywheresoftware.b4a.keywords.Common.NumberFormat2(_n,(int) (4),(int) (0),(int) (0),anywheresoftware.b4a.keywords.Common.False)))+"</td>")+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 209;BA.debugLine="sb.Append($\"<td style=\"text-align: left;\">明月面系列A";
_sb.Append(("<td style=\"text-align: left;\">明月面系列A"+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(anywheresoftware.b4a.keywords.Common.NumberFormat2(_n,(int) (4),(int) (0),(int) (0),anywheresoftware.b4a.keywords.Common.False)))+"</td>")+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 210;BA.debugLine="sb.Append($\"<td style=\"text-align: right;\">${Num";
_sb.Append(("<td style=\"text-align: right;\">"+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(anywheresoftware.b4a.keywords.Common.NumberFormat(_n,(int) (0),(int) (0))))+"</td>")+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 211;BA.debugLine="sb.Append($\"<td ></td>\"$&CRLF)";
_sb.Append(("<td ></td>")+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 212;BA.debugLine="sb.Append($\"</tr>\"$&CRLF)";
_sb.Append(("</tr>")+anywheresoftware.b4a.keywords.Common.CRLF);
 if (true) break;
if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 216;BA.debugLine="Dim strHTML As String";
_strhtml = "";
 //BA.debugLineNum = 218;BA.debugLine="strHTML = File.ReadString(repfolder, \"rep02_Conte";
_strhtml = anywheresoftware.b4a.keywords.Common.File.ReadString(parent._repfolder,"rep02_Content.html");
 //BA.debugLineNum = 219;BA.debugLine="strHTML = strHTML.Replace(\"{view}\", sb.ToString )";
_strhtml = _strhtml.replace("{view}",_sb.ToString());
 //BA.debugLineNum = 222;BA.debugLine="File.WriteString(repfolder,\"temp2.html\",strHTML)";
anywheresoftware.b4a.keywords.Common.File.WriteString(parent._repfolder,"temp2.html",_strhtml);
 //BA.debugLineNum = 225;BA.debugLine="Dim strHTML As String";
_strhtml = "";
 //BA.debugLineNum = 227;BA.debugLine="strHTML = File.ReadString(repfolder, \"rep02_heade";
_strhtml = anywheresoftware.b4a.keywords.Common.File.ReadString(parent._repfolder,"rep02_header.html");
 //BA.debugLineNum = 228;BA.debugLine="strHTML = strHTML.Replace(\"{title}\", \"商品明細表\")";
_strhtml = _strhtml.replace("{title}","商品明細表");
 //BA.debugLineNum = 231;BA.debugLine="File.WriteString(repfolder,\"temp1.html\",strHTML)";
anywheresoftware.b4a.keywords.Common.File.WriteString(parent._repfolder,"temp1.html",_strhtml);
 //BA.debugLineNum = 234;BA.debugLine="Dim p() As String";
_p = new String[(int) (0)];
java.util.Arrays.fill(_p,"");
 //BA.debugLineNum = 236;BA.debugLine="pdfName = \"1.pdf\"";
parent._pdfname = "1.pdf";
 //BA.debugLineNum = 239;BA.debugLine="p = Array As String(\"--header-html\",repfolder&\"te";
_p = new String[]{"--header-html",parent._repfolder+"temp1.html","--footer-html",parent._repfolder+"rep02_footer.html","--javascript-delay 	","500","--enable-local-file-access",parent._repfolder+"temp2.html",parent._repfolder+parent._pdfname};
 //BA.debugLineNum = 243;BA.debugLine="PdfSh.Initialize(\"PdfPrint\", \"c:\\program files\\wk";
_pdfsh.Initialize("PdfPrint","c:\\program files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe",anywheresoftware.b4a.keywords.Common.ArrayToList(_p));
 //BA.debugLineNum = 244;BA.debugLine="PdfSh.WorkingDirectory = repfolder";
_pdfsh.setWorkingDirectory(parent._repfolder);
 //BA.debugLineNum = 247;BA.debugLine="PdfSh.Run(-1)";
_pdfsh.Run(ba,(long) (-1));
 //BA.debugLineNum = 248;BA.debugLine="Wait For PdfSh_ProcessCompleted (Success As Boole";
anywheresoftware.b4a.keywords.Common.WaitFor("pdfsh_processcompleted", ba, this, null);
this.state = 13;
return;
case 13:
//C
this.state = 5;
_success = (boolean) result[0];
_exitcode = (int) result[1];
_stdout = (String) result[2];
_stderr = (String) result[3];
;
 //BA.debugLineNum = 249;BA.debugLine="If Success And ExitCode = 0 Then";
if (true) break;

case 5:
//if
this.state = 10;
if (_success && _exitcode==0) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 250;BA.debugLine="Log(\"Success\")";
anywheresoftware.b4a.keywords.Common.LogImpl("1655415","Success",0);
 //BA.debugLineNum = 251;BA.debugLine="Log(StdOut)";
anywheresoftware.b4a.keywords.Common.LogImpl("1655416",_stdout,0);
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 253;BA.debugLine="Log(\"Error: \" & StdErr)";
anywheresoftware.b4a.keywords.Common.LogImpl("1655418","Error: "+_stderr,0);
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 257;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _pdfsh_processcompleted(boolean _success,int _exitcode,String _stdout,String _stderr) throws Exception{
}
public static String  _pdfprint_processcompleted(boolean _success,int _exitcode,String _stdout,String _stderr) throws Exception{
String _fileseparator = "";
String _appdir = "";
String _osname = "";
 //BA.debugLineNum = 86;BA.debugLine="Sub PdfPrint_ProcessCompleted (Success As Boolean,";
 //BA.debugLineNum = 87;BA.debugLine="Log(StdOut)";
anywheresoftware.b4a.keywords.Common.LogImpl("1196609",_stdout,0);
 //BA.debugLineNum = 88;BA.debugLine="Log(StdErr)";
anywheresoftware.b4a.keywords.Common.LogImpl("1196610",_stderr,0);
 //BA.debugLineNum = 89;BA.debugLine="Dim FileSeparator As String=\"/\"";
_fileseparator = "/";
 //BA.debugLineNum = 90;BA.debugLine="Dim AppDir As String=\"appdir\"";
_appdir = "appdir";
 //BA.debugLineNum = 91;BA.debugLine="Dim OsName As String=asJO(Me).RunMethod(\"getSysPr";
_osname = BA.ObjectToString(_asjo((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(main.getObject()))).RunMethod("getSysProp",(Object[])(new String[]{"os.name"})));
 //BA.debugLineNum = 92;BA.debugLine="If Success And ExitCode = 0 Then";
if (_success && _exitcode==0) { 
 //BA.debugLineNum = 93;BA.debugLine="If OsName.Contains(\"Windows\") Then";
if (_osname.contains("Windows")) { 
 //BA.debugLineNum = 94;BA.debugLine="fx.ShowExternalDocument(File.GetUri(repfolder,p";
_fx.ShowExternalDocument(anywheresoftware.b4a.keywords.Common.File.GetUri(_repfolder,_pdfname));
 }else if(_osname.contains("Linux")) { 
 //BA.debugLineNum = 96;BA.debugLine="fx.ShowExternalDocument( AppDir & FileSeparator";
_fx.ShowExternalDocument(_appdir+_fileseparator+_pdfname);
 };
 }else {
 //BA.debugLineNum = 99;BA.debugLine="fx.Msgbox(MainForm,\"Check wkhtmltopdf error mess";
_fx.Msgbox(_mainform,"Check wkhtmltopdf error messages in log","Stop");
 };
 //BA.debugLineNum = 101;BA.debugLine="End Sub";
return "";
}
public static String  _printpdf() throws Exception{
anywheresoftware.b4j.objects.Shell _pdfsh = null;
anywheresoftware.b4j.objects.collections.JSONParser.JSONGenerator _jsongenerator = null;
int _n = 0;
anywheresoftware.b4a.objects.collections.Map _data = null;
anywheresoftware.b4a.objects.collections.List _lst = null;
anywheresoftware.b4a.objects.collections.Map _d1 = null;
String _json = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
long _t = 0L;
boolean _fileready = false;
 //BA.debugLineNum = 29;BA.debugLine="Sub PrintPdf()";
 //BA.debugLineNum = 30;BA.debugLine="Dim PdfSh As Shell";
_pdfsh = new anywheresoftware.b4j.objects.Shell();
 //BA.debugLineNum = 32;BA.debugLine="If File.Exists(repfolder,\"render.js\") Then";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_repfolder,"render.js")) { 
 //BA.debugLineNum = 33;BA.debugLine="File.Delete(repfolder,\"render.js\")";
anywheresoftware.b4a.keywords.Common.File.Delete(_repfolder,"render.js");
 };
 //BA.debugLineNum = 36;BA.debugLine="Dim JSONGenerator As JSONGenerator";
_jsongenerator = new anywheresoftware.b4j.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 37;BA.debugLine="Dim n As Int";
_n = 0;
 //BA.debugLineNum = 38;BA.debugLine="Dim data As Map";
_data = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 39;BA.debugLine="data.Initialize";
_data.Initialize();
 //BA.debugLineNum = 40;BA.debugLine="Dim lst As List";
_lst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 41;BA.debugLine="lst.Initialize";
_lst.Initialize();
 //BA.debugLineNum = 42;BA.debugLine="For n=0 To 15";
{
final int step11 = 1;
final int limit11 = (int) (15);
_n = (int) (0) ;
for (;_n <= limit11 ;_n = _n + step11 ) {
 //BA.debugLineNum = 43;BA.debugLine="Dim d1 As Map";
_d1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 44;BA.debugLine="d1.Initialize";
_d1.Initialize();
 //BA.debugLineNum = 45;BA.debugLine="d1.Put(\"category\",\"a1-\" & n)";
_d1.Put((Object)("category"),(Object)("a1-"+BA.NumberToString(_n)));
 //BA.debugLineNum = 46;BA.debugLine="d1.Put(\"Description\",\"a2-\" & n)";
_d1.Put((Object)("Description"),(Object)("a2-"+BA.NumberToString(_n)));
 //BA.debugLineNum = 47;BA.debugLine="d1.Put(\"title\",\"a3-\" & n)";
_d1.Put((Object)("title"),(Object)("a3-"+BA.NumberToString(_n)));
 //BA.debugLineNum = 48;BA.debugLine="d1.Put(\"Video\",\"a4-\" & n)";
_d1.Put((Object)("Video"),(Object)("a4-"+BA.NumberToString(_n)));
 //BA.debugLineNum = 49;BA.debugLine="lst.Add(d1)";
_lst.Add((Object)(_d1.getObject()));
 }
};
 //BA.debugLineNum = 52;BA.debugLine="data.Put(\"shows\",lst)";
_data.Put((Object)("shows"),(Object)(_lst.getObject()));
 //BA.debugLineNum = 54;BA.debugLine="JSONGenerator.Initialize(data)";
_jsongenerator.Initialize(_data);
 //BA.debugLineNum = 56;BA.debugLine="Dim json As String= JSONGenerator.ToString";
_json = _jsongenerator.ToString();
 //BA.debugLineNum = 58;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 59;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 60;BA.debugLine="sb.Append(\"function renderdoc(){\")";
_sb.Append("function renderdoc(){");
 //BA.debugLineNum = 61;BA.debugLine="sb.Append(\"var template = document.getElementById";
_sb.Append("var template = document.getElementById('template').innerHTML;");
 //BA.debugLineNum = 62;BA.debugLine="sb.Append(\"var rendered = Mustache.render(templat";
_sb.Append("var rendered = Mustache.render(template,"+_json+");");
 //BA.debugLineNum = 63;BA.debugLine="sb.Append(\"document.getElementById('target').inne";
_sb.Append("document.getElementById('target').innerHTML = rendered;");
 //BA.debugLineNum = 64;BA.debugLine="sb.Append(\"}\")";
_sb.Append("}");
 //BA.debugLineNum = 66;BA.debugLine="File.WriteString(repfolder,\"render.js\",sb.ToStrin";
anywheresoftware.b4a.keywords.Common.File.WriteString(_repfolder,"render.js",_sb.ToString());
 //BA.debugLineNum = 68;BA.debugLine="Dim t As Long = DateTime.Now";
_t = anywheresoftware.b4a.keywords.Common.DateTime.getNow();
 //BA.debugLineNum = 69;BA.debugLine="Dim fileready As Boolean=False";
_fileready = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 70;BA.debugLine="Do While fileready=False And DateTime.Now < t+500";
while (_fileready==anywheresoftware.b4a.keywords.Common.False && anywheresoftware.b4a.keywords.Common.DateTime.getNow()<_t+5000) {
 //BA.debugLineNum = 71;BA.debugLine="If File.Exists(repfolder,\"render.js\") Then";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_repfolder,"render.js")) { 
 //BA.debugLineNum = 72;BA.debugLine="fileready=True";
_fileready = anywheresoftware.b4a.keywords.Common.True;
 };
 }
;
 //BA.debugLineNum = 75;BA.debugLine="If fileready=True Then";
if (_fileready==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 77;BA.debugLine="PdfSh.Initialize(\"PdfPrint\", \"c:\\program files\\w";
_pdfsh.Initialize("PdfPrint","c:\\program files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe",anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"--javascript-delay 	","500","--enable-local-file-access",_repfolder+"report.html",_repfolder+_pdfname}));
 //BA.debugLineNum = 78;BA.debugLine="PdfSh.WorkingDirectory = repfolder";
_pdfsh.setWorkingDirectory(_repfolder);
 //BA.debugLineNum = 79;BA.debugLine="PdfSh.Run(5000)";
_pdfsh.Run(ba,(long) (5000));
 }else {
 //BA.debugLineNum = 81;BA.debugLine="fx.Msgbox(MainForm,\"Check wkhtmltopdf and report";
_fx.Msgbox(_mainform,"Check wkhtmltopdf and report paths","Stop");
 };
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4j.example.dateutils._process_globals();
b4j.example.cssutils._process_globals();
main._process_globals();
xuiviewsutils._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 10;BA.debugLine="Private Button1 As Button";
_button1 = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Private pdfName As String = \"report.pdf\"";
_pdfname = "report.pdf";
 //BA.debugLineNum = 12;BA.debugLine="Private repfolder As String = File.DirApp&\"\\\" '\"e";
_repfolder = anywheresoftware.b4a.keywords.Common.File.getDirApp()+"\\";
 //BA.debugLineNum = 13;BA.debugLine="Private Button3 As B4XView";
_button3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public static String  _sh1_stdout(byte[] _buffer,int _length) throws Exception{
 //BA.debugLineNum = 188;BA.debugLine="Sub sh1_StdOut (Buffer() As Byte, Length As Int)";
 //BA.debugLineNum = 189;BA.debugLine="Log(\"sh1_StdOut==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("1589825","sh1_StdOut==>",0);
 //BA.debugLineNum = 191;BA.debugLine="Log(BytesToString(Buffer,0,Buffer.Length,\"BIG5\"))";
anywheresoftware.b4a.keywords.Common.LogImpl("1589827",anywheresoftware.b4a.keywords.Common.BytesToString(_buffer,(int) (0),_buffer.length,"BIG5"),0);
 //BA.debugLineNum = 193;BA.debugLine="End Sub";
return "";
}
public static String  _shl_processcompleted(boolean _success,int _exitcode,String _stdout,String _stderr) throws Exception{
byte[] _data = null;
 //BA.debugLineNum = 165;BA.debugLine="Sub shl_ProcessCompleted (Success As Boolean, Exit";
 //BA.debugLineNum = 166;BA.debugLine="Log(\"shl_ProcessCompleted==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("1524289","shl_ProcessCompleted==>",0);
 //BA.debugLineNum = 168;BA.debugLine="If Success And ExitCode = 0 Then";
if (_success && _exitcode==0) { 
 //BA.debugLineNum = 169;BA.debugLine="Log(\"Success\")";
anywheresoftware.b4a.keywords.Common.LogImpl("1524292","Success",0);
 //BA.debugLineNum = 170;BA.debugLine="Log(StdOut)";
anywheresoftware.b4a.keywords.Common.LogImpl("1524293",_stdout,0);
 //BA.debugLineNum = 172;BA.debugLine="File.WriteString(File.DirApp,\"log0.txt\",StdOut)";
anywheresoftware.b4a.keywords.Common.File.WriteString(anywheresoftware.b4a.keywords.Common.File.getDirApp(),"log0.txt",_stdout);
 //BA.debugLineNum = 178;BA.debugLine="Dim Data() As Byte";
_data = new byte[(int) (0)];
;
 //BA.debugLineNum = 179;BA.debugLine="Data = StdOut.GetBytes(\"BIG5\")";
_data = _stdout.getBytes("BIG5");
 //BA.debugLineNum = 183;BA.debugLine="File.WriteString(File.DirApp,\"log.txt\",BytesToSt";
anywheresoftware.b4a.keywords.Common.File.WriteString(anywheresoftware.b4a.keywords.Common.File.getDirApp(),"log.txt",anywheresoftware.b4a.keywords.Common.BytesToString(_data,(int) (0),_data.length,"BIG5"));
 }else {
 //BA.debugLineNum = 185;BA.debugLine="Log(\"Error: \" & StdErr)";
anywheresoftware.b4a.keywords.Common.LogImpl("1524308","Error: "+_stderr,0);
 };
 //BA.debugLineNum = 187;BA.debugLine="End Sub";
return "";
}
//import java.io.File;


public static String getAppPath(){
    String userDir = System.getProperty("user.dir");
	return userDir;
}
public static String getSysProp(String fld){
    String data = System.getProperty(fld);
	return data;
}

public static void vshell (String s) {
    try {            
            Runtime rt = Runtime.getRuntime ();
            Process proc = rt.exec (s);
            String line = null;
 
            InputStream stderr = proc.getErrorStream ();
            InputStreamReader esr = new InputStreamReader (stderr);
            BufferedReader ebr = new BufferedReader (esr);
            System.out.println ("<error>");
            while ( (line = ebr.readLine ()) != null)
                System.out.println(line);
            System.out.println ("</error>");
             
            InputStream stdout = proc.getInputStream ();
            InputStreamReader osr = new InputStreamReader (stdout);
            BufferedReader obr = new BufferedReader (osr);
            System.out.println ("<output>");
            while ( (line = obr.readLine ()) != null)
                System.out.println(line);
            System.out.println ("</output>");
 
            int exitVal = proc.waitFor ();
            System.out.println ("Process exitValue: " + exitVal);
        } catch (Exception e) {
            e.printStackTrace();
        }
}		
}
